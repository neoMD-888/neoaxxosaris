# NeO-RON v5 — বাংলা AI + Live Desktop Chat

এই প্রজেক্টটি তোমার NeO-RON v4 কোডের আপগ্রেড। v5-ও **NumPy-ভিত্তিক character-level MLP**, Transformer নয়। পুরোনো v4-এর `.npz` মডেল ফাইল `--resume` এবং Chat UI-তে লোড করা যাবে।

## Project files

- `microbot5.py` — TXT / XLSX / CSV / TSV এবং approved chat `.jsonl` দিয়ে ট্রেনিং ও টেক্সট জেনারেশন।
- `neo_chat.py` — colorful, resizable Tkinter desktop Chat UI, Python standard library-র UI।
- `requirements.txt` — NumPy dependency।
- `data/neo_memory.jsonl` — Chat UI প্রথম চালানোর পর তৈরি হবে। **এই এক ফাইলেই** chat history এবং approve করা Q/A থাকে।
- `data/training.log` — UI থেকে approved answers train করলে log থাকবে।

## Kali Linux install

প্রথমে Python, Tkinter, venv ইনস্টল করো (যদি আগে না থাকে):

```bash
sudo apt update
sudo apt install -y python3 python3-tk python3-venv
```

তারপর তোমার প্রজেক্টের ফোল্ডারে এই ফাইলগুলো রাখো এবং:

```bash
cd ~/Micro-BoT/traningmodels
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

**Note:** `requirements.txt` ইনস্টল করার জন্য ইন্টারনেট লাগতে পারে। একবার ইনস্টল হয়ে গেলে মডেল লোকালি কাজ করবে।

## 1) GUI চালাও

```bash
python neo_chat.py
```

`NeO-RON-QA.npz` বর্তমান ফোল্ডারে থাকলে UI নিজেই খুঁজবে; না পেলে `Choose .npz model` ব্যবহার করো। এখনই মেসেজ করা যাবে।

**শেখানো:** মেসেজ → AI-এর উত্তর → `শেখাও / Correct answer` → সঠিক উত্তর লিখে `Save & remember`। পরের বার **হুবহু একই প্রশ্ন** করলে সেই উত্তর সঙ্গে সঙ্গে মনে পড়বে। এই শেখানো তথ্য `data/neo_memory.jsonl`-এ সেভ হয়।

**Neural weight training:** Chat-এর সব ভুল উত্তরের ওপর স্বয়ংক্রিয়ভাবে training হয় না। অন্তত পাঁচটি প্রশ্নের সঠিক উত্তর শেখানোর পর `Train approved answers` চাপলে নতুন `<model>-learned.npz` তৈরি হবে; পুরোনো model file থাকবে। খুব অল্প Q/A দিলে ফল খারাপ হতে পারে, তাই বেশি ও বৈচিত্র্যময় approved examples ব্যবহার করো।

## 2) অন্য Terminal-এ Training, GUI-তে live checkpoint

প্রথমে একই `.npz` ফাইলের backup রাখো:

```bash
cp NeO-RON-QA.npz NeO-RON-QA-backup.npz
```

তারপর:

```bash
python microbot5.py train \
  --data NeO-RON_Bangla_New_QA_50000.txt \
  --resume NeO-RON-QA.npz \
  --out NeO-RON-QA.npz \
  --epochs 3 \
  --save-every 1 \
  --save-best \
  --shuffle-records
```

আরেকটি Terminal-এ `python neo_chat.py` চালিয়ে কথা বলতে পারবে। প্রতি epoch শেষে নতুন checkpoint **atomically** সেভ হবে এবং GUI প্রায় দুই সেকেন্ড পর পরিবর্তন শনাক্ত করে মডেল নতুন করে লোড করবে। Training চলতে থাকলে CPU-এর চাপের কারণে উত্তর আসতে দেরি হতে পারে। একই `.npz`-তে একই সময়ে একাধিক train command চালিও না।

## 3) নতুন Excel Dataset দিয়ে Question–Answer training

প্রথম দুই কলাম প্রশ্ন ও উত্তর হলে:

```bash
python microbot5.py train \
  --data NeO-RON_Bangla_QA_100000.xlsx \
  --sheet 1 --columns 1,2 --skip-header --qa-format \
  --shuffle-records \
  --resume NeO-RON-QA.npz \
  --out NeO-RON-QA-v5.npz \
  --epochs 3 --save-best
```

`--qa-format` কলাম ১ ও ২-কে এই রূপে সাজায়:

```
প্রশ্ন: তুমি কেমন আছো?
উত্তর: আমি ভালো আছি।

```

**বিঃদ্রঃ** v4 আগের ট্রেনিংয়ে ট্যাব দিয়ে দুই কলাম জুড়েছিল। এই নতুন ফরম্যাট Q/A learning-এর জন্য বেশি উপযুক্ত। কিন্তু মডেল এখনো খুব ছোট, তাই সঠিক উত্তর নিশ্চিত নয়।

## 4) আগের model-এর Context 16 থেকে 64 বাড়াও

```bash
python microbot5.py train \
  --data NeO-RON_Bangla_New_QA_50000.txt \
  --resume NeO-RON-QA.npz \
  --context 64 \
  --out NeO-RON-v5-context64.npz \
  --epochs 3 --save-best --shuffle-records
```

এটা পুরোনো weights ধরে `W1`-এর বাম দিকে নতুন জায়গা যোগ করে। নতুন Context ব্যবহার শেখাতে **আবার ট্রেনিং লাগে**। Context বাড়ালে CPU-তে training ধীর হতে পারে। এটি Attention / Transformer যোগ করে না।

## 5) Command-line generation

```bash
python microbot5.py generate \
  --model NeO-RON-QA.npz \
  --prompt 'প্রশ্ন: তোমার নাম কী?\nউত্তর:' \
  --length 120 --temperature 0.5 --top-k 10
```

Bash-এর single quoted string-এ `\n` আসল newline নয়। আসল newline দিতে:

```bash
python microbot5.py generate \
  --model NeO-RON-QA.npz \
  --prompt $'প্রশ্ন: তোমার নাম কী?\nউত্তর:' \
  --length 120 --temperature 0.5 --top-k 10 --reply-only
```

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- v5-এ উন্নত chat UI, checkpoint reload, context expansion ও efficient training আছে; Neural architecture এখনো ছোট **MLP**।
- শেখানো Q/A হুবহু মিললে memory থেকে উত্তর আসে; অন্য প্রশ্নে model generate করে, সেখানে ভুল হতে পারে।
- Chat history local `data/neo_memory.jsonl`-এ **plaintext**-এ থাকে। ব্যক্তিগত তথ্য লিখলে ফাইলটিও ব্যক্তিগতভাবে সুরক্ষিত রাখবে।
- `--save-best` ব্যবহার করলে Validation loss অনুযায়ী আলাদা `-best.npz` checkpoint পাওয়া যায়। `--out` সর্বশেষ model, `-best.npz` ভালো Validation checkpoint।
- Input `--resume` এবং output `--out` একই `.npz` হলে v5 atomic saving ব্যবহার করে, কিন্তু Training চলাকালীন RAM-এ থাকা model-এ আগের checkpoint থেকেই weights আপডেট হবে।
