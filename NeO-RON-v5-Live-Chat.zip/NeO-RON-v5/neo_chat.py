#!/usr/bin/env python3
"""NeO-RON v5 — offline colorful desktop chat for Tkinter (no extra UI packages).

One JSONL data file stores chat turns and explicitly taught responses. Taught
answers are used instantly through exact-memory retrieval; model weight updates
need a separate short training run and are never inferred from incorrect replies.
"""
from __future__ import annotations
import json
import queue
import re
import subprocess
import sys
import threading
import time
import unicodedata
import uuid
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, font as tkfont

from microbot5 import TinyGPT

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
JOURNAL = DATA_DIR / "neo_memory.jsonl"
TRAIN_LOG = DATA_DIR / "training.log"
BG, PANEL, PANEL2, BORDER = "#08101F", "#101D32", "#182943", "#273B5C"
WHITE, MUTED, CYAN, PURPLE, GREEN = "#EAF3FF", "#94A8C7", "#35D4ED", "#9261FF", "#4ADEAC"
UI_FONT = "Noto Sans Bengali"    # Tk falls back if font is unavailable.


def now():
    return datetime.now().astimezone().isoformat(timespec="seconds")


def norm(text):
    text = unicodedata.normalize("NFKC", str(text)).strip().casefold()
    return re.sub(r"\s+", " ", text).strip("।!?.,:; ")


def write_event(event):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with JOURNAL.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(event, ensure_ascii=False) + "\n")
        fh.flush()


def read_events():
    if not JOURNAL.is_file():
        return [], {}
    turns, teachings = [], {}
    with JOURNAL.open(encoding="utf-8") as fh:
        for line in fh:
            try:
                ev = json.loads(line)
            except (ValueError, TypeError):
                continue
            if ev.get("kind") == "turn":
                turns.append(ev)
            elif ev.get("kind") == "teach":
                key = norm(ev.get("question", ""))
                answer = str(ev.get("answer", "")).strip()
                if key and answer:
                    teachings[key] = answer
    return turns[-20:], teachings


def rounded(canvas, x1, y1, x2, y2, radius, color, outline=None):
    r = min(radius, (x2-x1)/2, (y2-y1)/2)
    pts = [x1+r,y1, x2-r,y1, x2,y1, x2,y1+r,
           x2,y2-r, x2,y2, x2-r,y2, x1+r,y2,
           x1,y2, x1,y2-r, x1,y1+r, x1,y1]
    return canvas.create_polygon(pts, smooth=True, splinesteps=16, fill=color,
                                  outline=outline or color, width=1)


class RoundButton(tk.Canvas):
    def __init__(self,parent,text,command,color=PURPLE,width=190,height=40,
                 hover=None,text_color=WHITE,align="center",**kw):
        super().__init__(parent,width=width,height=height,bg=kw.pop("bg",PANEL),
                         highlightthickness=0,borderwidth=0,cursor="hand2",**kw)
        self.label, self.action, self.color = text,command,color
        self.hover = hover or "#426199"
        self.current = color
        self.text_color=text_color
        self.align=align
        self.enabled=True
        self.bind("<Configure>",lambda e:self.draw())
        self.bind("<Enter>",lambda e:self.paint(self.hover))
        self.bind("<Leave>",lambda e:self.paint(self.color))
        self.bind("<Button-1>",self.click)
        self.draw()

    def draw(self):
        self.delete("all")
        w=max(self.winfo_width(), int(self.cget("width")))
        h=max(self.winfo_height(), int(self.cget("height")))
        rounded(self,1,1,w-1,h-1,13,self.current)
        x = (w/2 if self.align == "center" else 15)
        self.create_text(x,h/2,text=self.label,anchor="center" if self.align=="center" else "w",
                         font=(UI_FONT,10,"bold"),fill=self.text_color)

    def paint(self,color):
        self.current = color if self.enabled else BORDER
        self.draw()

    def click(self,_e):
        if self.enabled:
            self.action()

    def update_text(self,text,enabled=True):
        self.label=text
        self.enabled=enabled
        self.current=self.color if enabled else BORDER
        self.draw()


class ChatBubble(tk.Frame):
    def __init__(self,parent,role,text,stamp,available_width):
        super().__init__(parent,bg=BG)
        self.role,self.message,self.stamp=role,text,stamp
        self.canvas=tk.Canvas(self,bg=BG,highlightthickness=0,borderwidth=0)
        self.canvas.pack(side="right" if role=="user" else "left")
        self.resize(available_width)

    def resize(self,available):
        width = max(225,min(620,int(available)-80))
        if width == getattr(self,"_width",None):
            return
        self._width=width
        c=self.canvas
        c.delete("all")
        font=(UI_FONT,12)
        f_title=(UI_FONT,10,"bold")
        txt=c.create_text(17,38,anchor="nw",fill=WHITE,font=font,text=self.message,
                           width=width-34,justify="left")
        bbox=c.bbox(txt)
        h=max(89, bbox[3]+34)
        c.configure(width=width,height=h)
        main = "#2A4085" if self.role=="user" else PANEL2
        line = "#3D5DB9" if self.role=="user" else BORDER
        shape=rounded(c,1,1,width-1,h-1,17,main,outline=line)
        c.tag_lower(shape)
        c.create_text(17,14,text="YOU" if self.role=="user" else "◈ NeO-RON",
                      font=f_title,fill="#BFE9FF" if self.role=="user" else CYAN,anchor="nw")
        c.create_text(width-16,h-15,text=self.stamp,anchor="e",fill=MUTED,font=(UI_FONT,9))


class NeoChat(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NeO-RON v5 · Live Chat Lab")
        self.geometry("1130x755")
        self.minsize(680,525)
        self.configure(bg=BG)
        self.session=str(uuid.uuid4())
        self.jobs=queue.Queue()
        self.model=None
        self.chars=[]
        self.stoi={}
        self.model_stamp=None
        self.model_busy=False
        self.reply_busy=False
        self.teach_running=None
        self.last_turn=None
        self.sidebar_shown=True
        turns,self.teachings=read_events()
        models=[Path.cwd()/"NeO-RON-QA.npz",ROOT/"NeO-RON-QA.npz"]
        models+=sorted(Path.cwd().glob("*.npz")) + sorted(ROOT.glob("*.npz"))
        self.model_path=next((p.resolve() for p in models if p.is_file() and not p.stem.endswith("-best")),
                             (Path.cwd()/"NeO-RON-QA.npz").resolve())
        self._build()
        if turns:
            for ev in turns[-12:]:
                self.add_bubble("user",ev.get("question",""),"history")
                self.add_bubble("ai",ev.get("answer",""),ev.get("source","model"))
        else:
            self.add_bubble("ai","হ্যালো! আমি NeO-RON। এখানে কথা বলো, আর ‘শেখাও’ বোতামে আমার উত্তর সংশোধন করে আমাকে মনে রাখতে শেখাও।", "Welcome")
        self.memory_label.configure(text=f"{len(self.teachings):,} approved answers")
        self.after(120,self.queue_poll)
        self.after(250,self.auto_reload)
        self.after(600,self.training_poll)

    def section(self,name):
        tk.Label(self.sidebar,text=name,bg=PANEL,fg=MUTED,font=(UI_FONT,9,"bold"),
                 anchor="w").pack(fill="x",padx=23,pady=(16,5))

    def side_button(self,text,fn,fg=PANEL2):
        w=RoundButton(self.sidebar,text,fn,color=fg,width=210,height=40,align="left")
        w.pack(fill="x",padx=20,pady=5)
        return w

    def _build(self):
        self.grid_rowconfigure(0,weight=1)
        self.grid_columnconfigure(1,weight=1)
        self.sidebar=tk.Frame(self,bg=PANEL,width=251)
        self.sidebar.grid(row=0,column=0,sticky="nsew")
        self.sidebar.grid_propagate(False)
        tk.Label(self.sidebar,text="◈  NeO-RON",bg=PANEL,fg=CYAN,
                 font=(UI_FONT,21,"bold"),anchor="w").pack(fill="x",padx=22,pady=(26,0))
        tk.Label(self.sidebar,text="LOCAL INTELLIGENCE    •    v5",bg=PANEL,fg=MUTED,
                 font=(UI_FONT,9,"bold"),anchor="w").pack(fill="x",padx=23,pady=(0,15))
        self.section("MODEL CHECKPOINT")
        self.model_name=tk.Label(self.sidebar,text=self.model_path.name,bg=PANEL,fg=WHITE,
                                  font=(UI_FONT,11,"bold"),wraplength=212,justify="left",anchor="w")
        self.model_name.pack(fill="x",padx=23,pady=(2,8))
        self.side_button("◉  Choose .npz model",self.choose_model,PURPLE)
        self.side_button("↻  Reload latest weights",self.force_reload)
        self.side_status=tk.Label(self.sidebar,text="● Waiting for checkpoint",bg=PANEL,fg=MUTED,
                                   font=(UI_FONT,10),wraplength=205,anchor="w",justify="left")
        self.side_status.pack(fill="x",padx=23,pady=(12,6))
        tk.Frame(self.sidebar,bg=BORDER,height=1).pack(fill="x",padx=23,pady=8)
        self.section("LEARNING MEMORY")
        self.memory_label=tk.Label(self.sidebar,text="0 approved answers",bg=PANEL,
                                    fg=GREEN,font=(UI_FONT,12,"bold"),anchor="w")
        self.memory_label.pack(fill="x",padx=23,pady=(0,4))
        tk.Label(self.sidebar,text="All chats are saved locally. Only answers YOU approve are used for training.",
                 bg=PANEL,fg=MUTED,wraplength=210,justify="left",font=(UI_FONT,10)).pack(fill="x",padx=23)
        self.side_button("✎  শেখাও / Correct answer",self.teach_answer)
        self.side_button("⚡  Train approved answers",self.memory_train,"#15596E")
        self.side_button("□  New chat",self.new_chat)
        self.training_info=tk.Label(self.sidebar,text="",bg=PANEL,fg=MUTED,
                                    font=(UI_FONT,9),wraplength=210,justify="left")
        self.training_info.pack(fill="x",padx=23,pady=8)
        tk.Label(self.sidebar,text="● Offline inference\n● Checkpoint auto-reload\n● One JSONL memory file",
                 bg=PANEL,fg=MUTED,justify="left",font=(UI_FONT,10)).pack(side="bottom",anchor="w",padx=24,pady=24)

        self.main=tk.Frame(self,bg=BG)
        self.main.grid(row=0,column=1,sticky="nsew")
        self.main.grid_rowconfigure(1,weight=1)
        self.main.grid_columnconfigure(0,weight=1)
        header=tk.Frame(self.main,bg=BG,height=85)
        header.grid(row=0,column=0,sticky="ew",padx=18)
        header.grid_columnconfigure(1,weight=1)
        RoundButton(header,"☰",self.toggle_sidebar,PANEL2,width=44,height=41,bg=BG).grid(row=0,column=0,pady=18)
        tblock=tk.Frame(header,bg=BG)
        tblock.grid(row=0,column=1,sticky="w",padx=15)
        tk.Label(tblock,text="Live Conversation",fg=WHITE,bg=BG,font=(UI_FONT,17,"bold")).pack(anchor="w")
        self.top_status=tk.Label(tblock,text="Looking for model...",fg=MUTED,bg=BG,font=(UI_FONT,10))
        self.top_status.pack(anchor="w")
        tk.Label(header,text="●  LOCAL · PRIVATE",fg=GREEN,bg=BG,
                 font=(UI_FONT,9,"bold")).grid(row=0,column=2,padx=(6,6))

        chat_area=tk.Frame(self.main,bg=BG)
        chat_area.grid(row=1,column=0,sticky="nsew",padx=(17,18),pady=3)
        chat_area.grid_rowconfigure(0,weight=1)
        chat_area.grid_columnconfigure(0,weight=1)
        self.chat_canvas=tk.Canvas(chat_area,bg=BG,highlightthickness=0,borderwidth=0)
        self.chat_canvas.grid(row=0,column=0,sticky="nsew")
        scrollbar=tk.Scrollbar(chat_area,orient="vertical",command=self.chat_canvas.yview,
                               bg=PANEL2,activebackground=PURPLE,troughcolor=BG)
        scrollbar.grid(row=0,column=1,sticky="ns")
        self.chat_canvas.configure(yscrollcommand=scrollbar.set)
        self.chat_frame=tk.Frame(self.chat_canvas,bg=BG)
        self.chat_window=self.chat_canvas.create_window((0,0),window=self.chat_frame,anchor="nw")
        self.chat_frame.bind("<Configure>",lambda _e:self.chat_canvas.configure(scrollregion=self.chat_canvas.bbox("all")))
        self.chat_canvas.bind("<Configure>",self.resize_chat)
        self.chat_canvas.bind("<MouseWheel>",self.mouse_scroll)
        self.chat_frame.bind("<MouseWheel>",self.mouse_scroll)
        self.bubbles=[]

        footer=tk.Frame(self.main,bg=PANEL,highlightbackground=BORDER,highlightthickness=1)
        footer.grid(row=2,column=0,sticky="ew",padx=23,pady=(9,20))
        footer.grid_columnconfigure(0,weight=1)
        top_f=tk.Frame(footer,bg=PANEL)
        top_f.grid(row=0,column=0,columnspan=2,sticky="ew",padx=17,pady=(12,4))
        tk.Label(top_f,text="MESSAGE",bg=PANEL,fg=MUTED,font=(UI_FONT,9,"bold")).pack(side="left")
        tk.Label(top_f,text="Enter: Send   •   Shift+Enter: newline",bg=PANEL,
                 fg=MUTED,font=(UI_FONT,9)).pack(side="right")
        self.compose=tk.Text(footer,height=3,wrap="word",bg=PANEL2,fg=WHITE,
                              insertbackground=CYAN,selectbackground="#3151A1",relief="flat",
                              padx=12,pady=9,font=(UI_FONT,11),undo=True)
        self.compose.grid(row=1,column=0,sticky="ew",padx=(15,8),pady=(1,10))
        self.compose.bind("<Return>",self.enter_send)
        self.send_button=RoundButton(footer,"Send ➜",self.send,PURPLE,width=101,height=68,bg=PANEL)
        self.send_button.grid(row=1,column=1,sticky="ns",padx=(0,14),pady=(1,10))
        setting=tk.Frame(footer,bg=PANEL)
        setting.grid(row=2,column=0,columnspan=2,sticky="ew",padx=17,pady=(0,12))
        tk.Label(setting,text="Temperature",fg=MUTED,bg=PANEL,font=(UI_FONT,10)).pack(side="left")
        self.temperature=tk.DoubleVar(value=0.65)
        self.temp_scale=tk.Scale(setting,from_=0.1,to=1.3,resolution=0.05,variable=self.temperature,
                                 orient="horizontal",length=135,showvalue=False,fg=CYAN,
                                 bg=PANEL,highlightthickness=0,troughcolor=BORDER,activebackground=CYAN,
                                 sliderrelief="flat",command=self.update_temperature)
        self.temp_scale.pack(side="left",padx=(5,0))
        self.temperature_text=tk.Label(setting,text="0.65",fg=WHITE,bg=PANEL,font=(UI_FONT,10))
        self.temperature_text.pack(side="left")
        tk.Label(setting,text="  Max chars",fg=MUTED,bg=PANEL,font=(UI_FONT,10)).pack(side="left",padx=(14,4))
        self.length=tk.StringVar(value="120")
        length_menu=tk.OptionMenu(setting,self.length,"60","120","200","300")
        length_menu.configure(bg=PANEL2,fg=WHITE,activebackground=BORDER,
                              highlightthickness=0,borderwidth=0,relief="flat",font=(UI_FONT,10))
        length_menu["menu"].configure(bg=PANEL2,fg=WHITE,activebackground=PURPLE)
        length_menu.pack(side="left")
        self.bind("<Configure>",self.on_window_resize)
        self.compose.focus_set()

    def update_temperature(self,_=None):
        self.temperature_text.configure(text=f"{self.temperature.get():.2f}")

    def on_window_resize(self,event):
        if event.widget is not self:
            return
        if self.winfo_width()<870 and self.sidebar_shown:
            self.sidebar_shown=False
            self.sidebar.grid_remove()

    def toggle_sidebar(self):
        self.sidebar_shown=not self.sidebar_shown
        if self.sidebar_shown:
            self.sidebar.grid()
        else:
            self.sidebar.grid_remove()

    def resize_chat(self,event):
        self.chat_canvas.itemconfigure(self.chat_window,width=event.width)
        for bubble in self.bubbles:
            bubble.resize(event.width)

    def mouse_scroll(self,event):
        self.chat_canvas.yview_scroll(int(-event.delta/120),"units")

    def add_bubble(self,role,text,stamp=""):
        if not text:
            return
        bubble=ChatBubble(self.chat_frame,role,text,stamp or datetime.now().strftime("%H:%M"),
                          max(300,self.chat_canvas.winfo_width()))
        bubble.pack(fill="x",padx=8,pady=8)
        self.bubbles.append(bubble)
        self.after(70,lambda:self.chat_canvas.yview_moveto(1.0))

    def enter_send(self,event):
        if event.state & 1:  # Shift+Enter inserts newline
            return None
        self.send()
        return "break"

    def send(self):
        if self.reply_busy:
            return
        question=self.compose.get("1.0","end-1c").strip()
        if not question:
            return
        self.compose.delete("1.0","end")
        self.add_bubble("user",question)
        self.reply_busy=True
        self.send_button.update_text("Thinking...",False)
        self.top_status.configure(text="Generating with local model...")
        remembered=self.teachings.get(norm(question))
        if remembered:
            self.jobs.put(("reply",question,remembered,"saved teaching"))
        else:
            threading.Thread(target=self.generate_worker,args=(question,float(self.temperature.get()),int(self.length.get())),daemon=True).start()

    def generate_worker(self,question,temp,length):
        try:
            model, chars, stoi=self.model,self.chars,self.stoi
            if model is None:
                raise RuntimeError("No model loaded — choose a .npz checkpoint")
            prompt=f"প্রশ্ন: {question}\nউত্তর:"
            random_seed=time.time_ns()%2147483647
            result=model.generate(stoi,chars,prompt,length,temp,10,random_seed)
            answer=result[len(prompt):]
            for stop in ("\n","প্রশ্ন:","ব্যবহারকারী:","উত্তর:"):
                answer=answer.split(stop,1)[0]
            answer=answer.strip() or "(আমি এখনো এই প্রশ্নের ভালো উত্তর তৈরি করতে পারিনি। ‘শেখাও’ দিয়ে আমাকে ঠিক উত্তরটি দাও।)"
            self.jobs.put(("reply",question,answer,"model"))
        except Exception as exc:
            self.jobs.put(("reply",question,f"⚠ {exc}","error"))

    def queue_poll(self):
        try:
            while True:
                kind,*args=self.jobs.get_nowait()
                if kind=="reply":
                    question,answer,source=args
                    self.add_bubble("ai",answer,source)
                    self.last_turn=(question,answer)
                    write_event({"kind":"turn","time":now(),"session":self.session,
                                 "question":question,"answer":answer,"source":source})
                    self.reply_busy=False
                    self.send_button.update_text("Send ➜",True)
                    self.top_status.configure(text=f"● Ready · {source}")
                if kind=="loaded":
                    path,model,chars,stamp=args
                    self.model_busy=False
                    if path!=self.model_path:
                        continue
                    self.model,self.chars,self.stoi=model,chars,{c:i for i,c in enumerate(chars)}
                    self.model_stamp=stamp
                    self.side_status.configure(text=f"● Ready · {model.context} character context",fg=GREEN)
                    self.top_status.configure(text=f"● Model ready · {len(chars)} symbols")
                if kind=="load_error":
                    path,error=args
                    self.model_busy=False
                    if path==self.model_path:
                        self.top_status.configure(text="Model load failed")
                        self.side_status.configure(text=f"● {error[:46]}",fg="#FB7185")
        except queue.Empty:
            pass
        self.after(120,self.queue_poll)

    def auto_reload(self):
        try:
            if self.model_path.is_file():
                s=self.model_path.stat()
                stamp=(s.st_mtime_ns,s.st_size)
                if stamp!=self.model_stamp and not self.model_busy:
                    self.model_busy=True
                    threading.Thread(target=self.load_worker,args=(self.model_path,stamp),daemon=True).start()
            elif self.model is None:
                self.side_status.configure(text="● Choose a .npz model",fg="#FB7185")
        except OSError:
            pass
        self.after(2100,self.auto_reload)

    def load_worker(self,path,stamp):
        try:
            model,chars,_=TinyGPT.load(path)
            self.jobs.put(("loaded",path,model,chars,stamp))
        except Exception as exc:
            self.jobs.put(("load_error",path,str(exc)))

    def choose_model(self):
        filename=filedialog.askopenfilename(title="Load NeO-RON checkpoint",filetypes=[("NumPy checkpoint","*.npz")])
        if filename:
            self.model_path=Path(filename).resolve()
            self.model=None
            self.model_stamp=None
            self.model_name.configure(text=self.model_path.name)
            self.side_status.configure(text="● Loading checkpoint...",fg=MUTED)

    def force_reload(self):
        self.model_stamp=None
        self.top_status.configure(text="Reload requested...")

    def new_chat(self):
        for item in self.chat_frame.winfo_children():
            item.destroy()
        self.bubbles=[]
        self.session=str(uuid.uuid4())
        self.last_turn=None
        self.add_bubble("ai","নতুন চ্যাট শুরু হয়েছে। আগের সব কথা একই data/neo_memory.jsonl ফাইলে আছে।","New session")

    def teach_answer(self):
        if self.last_turn is None:
            messagebox.showinfo("Teach NeO-RON","প্রথমে প্রশ্ন করে একটি উত্তর নাও, তারপর সেটি সংশোধন করো।")
            return
        question,old_answer=self.last_turn
        win=tk.Toplevel(self,bg=BG)
        win.title("Teach NeO-RON · Verified answer")
        win.geometry("580x405")
        win.minsize(420,310)
        win.transient(self)
        win.grab_set()
        tk.Label(win,text="✎  Teach a better answer",bg=BG,fg=CYAN,
                 font=(UI_FONT,16,"bold")).pack(anchor="w",padx=23,pady=(22,10))
        tk.Label(win,text="প্রশ্ন: "+question,bg=BG,fg=WHITE,font=(UI_FONT,11),
                 justify="left",wraplength=525).pack(anchor="w",padx=23,pady=(0,10))
        editor=tk.Text(win,bg=PANEL2,fg=WHITE,insertbackground=CYAN,
                        selectbackground=PURPLE,font=(UI_FONT,12),wrap="word",relief="flat",padx=12,pady=12)
        editor.pack(fill="both",expand=True,padx=22,pady=(0,10))
        if not old_answer.startswith(("⚠", "(")):
            editor.insert("1.0",old_answer)
        def commit():
            answer=editor.get("1.0","end-1c").strip()
            if not answer:
                messagebox.showwarning("Empty answer","প্রথমে সঠিক উত্তর লেখো।",parent=win)
                return
            self.teachings[norm(question)]=answer
            write_event({"kind":"teach","time":now(),"session":self.session,
                         "question":question,"answer":answer})
            self.memory_label.configure(text=f"{len(self.teachings):,} approved answers")
            self.add_bubble("ai","✓ উত্তরটি মনে রেখেছি। একই প্রশ্নে এখনই ব্যবহার করব। Training button দিয়ে weights-এও শেখাতে পারবে।","Memory saved")
            win.destroy()
        RoundButton(win,"✓  Save & remember",commit,PURPLE,width=300,height=43,bg=BG).pack(fill="x",padx=22,pady=(0,17))
        editor.focus_set()

    def memory_train(self):
        if self.teach_running is not None and self.teach_running.poll() is None:
            messagebox.showinfo("Training","Approved-answer training already running.")
            return
        if len(self.teachings)<5:
            messagebox.showinfo("Needs more examples","কমপক্ষে ৫টি আলাদা প্রশ্নের উত্তর শেখাও। বেশি উদাহরণ হলে আরও ভালো।")
            return
        if not self.model_path.is_file():
            messagebox.showerror("Model required","আগে একটি checkpoint লোড করো।")
            return
        target=self.model_path.with_name(self.model_path.stem+"-learned.npz")
        if not messagebox.askyesno("Learn from chats",
            f"শুধু {len(self.teachings)}টি verified answers দিয়ে ২ Epoch ট্রেন করব।\n\nপুরোনো: {self.model_path.name}\nনতুন: {target.name}\n\nContinue?"):
            return
        DATA_DIR.mkdir(parents=True,exist_ok=True)
        cmd=[sys.executable,str(ROOT/"microbot5.py"),"train","--data",str(JOURNAL),
             "--resume",str(self.model_path),"--out",str(target),"--epochs","2",
             "--lr","0.0005","--shuffle-records","--save-best","--gen-length","40"]
        self.train_stream=TRAIN_LOG.open("w",encoding="utf-8")
        try:
            self.teach_running=subprocess.Popen(cmd,stdout=self.train_stream,
                                                  stderr=subprocess.STDOUT,cwd=ROOT)
        except Exception as exc:
            self.train_stream.close()
            messagebox.showerror("Failed to train",str(exc))
            return
        self.teach_target=target
        self.training_info.configure(text="● Training saved answers; see data/training.log",fg=GREEN)

    def training_poll(self):
        if self.teach_running is not None:
            result=self.teach_running.poll()
            if result is not None:
                self.teach_running=None
                self.train_stream.close()
                if result==0 and self.teach_target.is_file():
                    self.model_path=self.teach_target.resolve()
                    self.model_stamp=None
                    self.model_name.configure(text=self.model_path.name)
                    self.training_info.configure(text="✓ New learned model ready",fg=GREEN)
                else:
                    self.training_info.configure(text="Training failed: see data/training.log",fg="#FB7185")
        self.after(1200,self.training_poll)


if __name__=="__main__":
    NeoChat().mainloop()
