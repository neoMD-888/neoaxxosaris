#!/usr/bin/env python3
"""NeO-RON v5 - backward-compatible NumPy character-level language model.

Not a Transformer. v4 weights can be resumed. Supports incremental chat GUI
checkpoints, larger context, lower-memory batches, XLSX, and approved chat memory.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import os
import sys
import time
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from posixpath import normpath
import numpy as np

VERSION = 5

def softmax(logits: np.ndarray) -> np.ndarray:
    z = logits - np.max(logits, axis=-1, keepdims=True)
    e = np.exp(z)
    return e / np.sum(e, axis=-1, keepdims=True)

class TinyGPT:

    def __init__(self, vocab_size: int, context: int = 16, emb: int = 32,

                 hidden: int = 64, seed: int = 42):

        self.vocab_size = int(vocab_size)

        self.context = int(context)

        self.emb = int(emb)

        self.hidden = int(hidden)

        rng = np.random.default_rng(seed)



        def weight(out_dim, in_dim):

            return (rng.standard_normal((out_dim, in_dim)) *

                    math.sqrt(2.0 / max(1, in_dim))).astype(np.float32)



        # Parameters: fixed context embeddings -> MLP -> next-character logits.

        self.p = {

            "E": (rng.standard_normal((vocab_size, emb)) * 0.05).astype(np.float32),

            "W1": weight(hidden, context * emb),

            "b1": np.zeros((hidden,), dtype=np.float32),

            "W2": weight(vocab_size, hidden),

            "b2": np.zeros((vocab_size,), dtype=np.float32),

        }

        self.m = {k: np.zeros_like(v) for k, v in self.p.items()}

        self.v = {k: np.zeros_like(v) for k, v in self.p.items()}

        self.opt_step = 0



    def extend_vocab(self, additional):
        """Grow embedding/output tensors without destroying learned weights."""
        extra = int(additional)
        if extra <= 0:
            return
        rng = np.random.default_rng(2026 + self.vocab_size)
        old = self.vocab_size
        self.vocab_size += extra
        additions = {
            "E": (rng.standard_normal((extra, self.emb)) * 0.05).astype(np.float32),
            "W2": (rng.standard_normal((extra, self.hidden)) * math.sqrt(2.0 / self.hidden)).astype(np.float32),
            "b2": np.zeros(extra, dtype=np.float32),
        }
        for name, values in additions.items():
            self.p[name] = np.concatenate((self.p[name], values), axis=0)
            for group in (self.m, self.v):
                group[name] = np.concatenate((group[name], np.zeros_like(values)), axis=0)

    def extend_context(self, new_context: int):
        """Expand receptive field; preserve old W1 weights on right-most positions."""
        new_context = int(new_context)
        if new_context < self.context:
            raise ValueError("Cannot shrink context when resuming an existing model")
        if new_context == self.context:
            return
        extra_cols = (new_context - self.context) * self.emb
        name = "W1"
        self.p[name] = np.pad(self.p[name], ((0, 0), (extra_cols, 0)))
        self.m[name] = np.pad(self.m[name], ((0, 0), (extra_cols, 0)))
        self.v[name] = np.pad(self.v[name], ((0, 0), (extra_cols, 0)))
        self.context = new_context

    def forward(self, x: np.ndarray, cache=False):

        # x: [batch, context]

        e = self.p["E"][x]                    # [B, C, D]

        flat = e.reshape(x.shape[0], -1)      # [B, C*D]

        z1 = flat @ self.p["W1"].T + self.p["b1"]

        h = np.tanh(z1)

        logits = h @ self.p["W2"].T + self.p["b2"]

        if cache:

            return logits, (x, e, flat, z1, h)

        return logits



    def loss_and_grads(self, x: np.ndarray, y: np.ndarray):

        logits, cache = self.forward(x, cache=True)

        x, e, flat, z1, h = cache

        probs = softmax(logits)

        n = x.shape[0]

        loss = -np.log(np.maximum(probs[np.arange(n), y], 1e-12)).mean()



        # Cross-entropy + softmax derivative.

        dlogits = probs

        dlogits[np.arange(n), y] -= 1.0

        dlogits /= n



        grads = {}

        grads["W2"] = dlogits.T @ h

        grads["b2"] = dlogits.sum(axis=0)

        dh = dlogits @ self.p["W2"]

        dz1 = dh * (1.0 - np.tanh(z1) ** 2)

        grads["W1"] = dz1.T @ flat

        grads["b1"] = dz1.sum(axis=0)

        dflat = dz1 @ self.p["W1"]

        de = dflat.reshape(n, self.context, self.emb)



        grads["E"] = np.zeros_like(self.p["E"])

        # Repeated character IDs must accumulate their gradients.

        np.add.at(grads["E"], x.reshape(-1), de.reshape(-1, self.emb))

        return float(loss), grads



    def update(self, grads, lr, beta1=0.9, beta2=0.999, eps=1e-8,

               grad_clip=1.0):

        norm = math.sqrt(sum(float(np.sum(g * g)) for g in grads.values()))

        if norm > grad_clip:

            scale = grad_clip / (norm + 1e-12)

            grads = {k: g * scale for k, g in grads.items()}



        self.opt_step += 1

        for k in self.p:

            g = grads[k]

            self.m[k] = beta1 * self.m[k] + (1.0 - beta1) * g

            self.v[k] = beta2 * self.v[k] + (1.0 - beta2) * (g * g)

            m_hat = self.m[k] / (1.0 - beta1 ** self.opt_step)

            v_hat = self.v[k] / (1.0 - beta2 ** self.opt_step)

            self.p[k] -= lr * m_hat / (np.sqrt(v_hat) + eps)



    def generate(self, stoi, itos, seed_text="", length=200, temperature=0.8,

                 top_k=0, seed=123):

        if temperature <= 0:

            raise ValueError("temperature must be greater than zero")

        rng = np.random.default_rng(seed)

        ids = [stoi[ch] for ch in seed_text if ch in stoi]

        if not ids:

            ids = [0]

        output = list(seed_text)

        for _ in range(length):

            ctx = ([0] * max(0, self.context - len(ids)) + ids[-self.context:])

            x = np.asarray([ctx], dtype=np.int64)

            logits = self.forward(x)[0] / temperature

            if top_k > 0 and top_k < self.vocab_size:

                keep = np.argpartition(logits, -top_k)[-top_k:]

                mask = np.full_like(logits, -1e9)

                mask[keep] = logits[keep]

                logits = mask

            probs = softmax(logits)

            next_id = int(rng.choice(self.vocab_size, p=probs))

            ids.append(next_id)

            output.append(itos[next_id])

        return "".join(output)



    def save(self, path, chars, config):

        payload = {

            "version": np.array([VERSION], dtype=np.int32),

            "chars": np.asarray(chars),

            "config": np.asarray(json.dumps(config)),

            "opt_step": np.array([self.opt_step], dtype=np.int64),

        }

        for group, values in (("p", self.p), ("m", self.m), ("v", self.v)):

            for name, arr in values.items():

                payload[f"{group}_{name}"] = arr

        # Atomic publish: chat readers never see a half-written checkpoint.
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.stem + ".partial.npz")
        np.savez_compressed(temporary, **payload)
        os.replace(temporary, path)



    @classmethod

    def load(cls, path):

        with np.load(path, allow_pickle=False) as data:

            chars = data["chars"].tolist()

            config = json.loads(str(data["config"].item()))

            model = cls(len(chars), **config)

            for group, values in (("p", model.p), ("m", model.m), ("v", model.v)):

                for name in values:

                    values[name][...] = data[f"{group}_{name}"]

            model.opt_step = int(data["opt_step"][0])

        return model, chars, config

def read_dataset(path: Path, sheet=None, columns=None, header=False):
    """Load UTF-8 TXT, CSV/TSV or Excel XLSX as character training text.

    Each spreadsheet row becomes a newline-terminated record. Selected cell
    values are joined by a TAB. Empty rows are ignored. XLSX formulas use
    Excel's cached values (recalculate/save in Excel if these are empty).
    """
    ext = path.suffix.lower()
    if ext == ".txt":
        return path.read_text(encoding="utf-8-sig")

    def select(values):
        if columns:
            values = [values[i - 1] if i <= len(values) else "" for i in columns]
        return "\t".join(str(v).strip() for v in values if str(v).strip())

    if ext in (".csv", ".tsv"):
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f, delimiter="\t" if ext == ".tsv" else ",")
            lines = []
            for row_num, row in enumerate(reader):
                if header and row_num == 0:
                    continue
                value = select(row)
                if value:
                    lines.append(value)
        return "\n".join(lines) + ("\n" if lines else "")

    if ext == ".xlsx":
        ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
              "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
        rns = "http://schemas.openxmlformats.org/package/2006/relationships"
        def col_num(ref):
            letters = "".join(c for c in ref if c.isalpha())
            result = 0
            for c in letters.upper():
                result = result * 26 + ord(c) - 64
            return result
        with zipfile.ZipFile(path) as z:
            wb = ET.fromstring(z.read("xl/workbook.xml"))
            rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
            targets = {r.attrib["Id"]: r.attrib["Target"] for r in rels.findall(f"{{{rns}}}Relationship")}
            sheets = wb.find("m:sheets", ns)
            options = [(item.attrib["name"], item.attrib[f"{{{ns['r']}}}id"]) for item in sheets]
            if not options:
                raise ValueError("Excel workbook has no sheets")
            if sheet is None:
                selected = options[0]
            elif str(sheet).isdigit():
                idx = int(sheet) - 1
                if idx < 0 or idx >= len(options):
                    raise ValueError(f"Sheet index must be 1..{len(options)}")
                selected = options[idx]
            else:
                matches = [s for s in options if s[0] == sheet]
                if not matches:
                    raise ValueError(f"Sheet '{sheet}' not found. Available: {[s[0] for s in options]}")
                selected = matches[0]
            target = targets[selected[1]].lstrip("/")
            sheet_path = normpath(target if target.startswith("xl/") else "xl/" + target)
            strings = []
            if "xl/sharedStrings.xml" in z.namelist():
                root = ET.fromstring(z.read("xl/sharedStrings.xml"))
                for si in root.findall("m:si", ns):
                    strings.append("".join((t.text or "") for t in si.findall(".//m:t", ns)))
            lines = []
            with z.open(sheet_path) as stream:
                for _, elem in ET.iterparse(stream, events=("end",)):
                    if elem.tag != f"{{{ns['m']}}}row":
                        continue
                    cells = {}
                    for c in elem.findall("m:c", ns):
                        ci = col_num(c.attrib.get("r", ""))
                        if not ci:
                            continue
                        t = c.attrib.get("t", "")
                        value = c.findtext("m:v", default="", namespaces=ns)
                        if t == "s" and value:
                            value = strings[int(value)]
                        elif t == "inlineStr":
                            value = "".join((x.text or "") for x in c.findall(".//m:t", ns))
                        elif t == "b" and value:
                            value = "TRUE" if value == "1" else "FALSE"
                        elif t == "e":
                            value = ""
                        cells[ci] = value
                    if not (header and not lines and int(elem.attrib.get("r", "1")) == 1):
                        values = [cells.get(i, "") for i in range(1, max(cells, default=0) + 1)]
                        value = select(values)
                        if value:
                            lines.append(value)
                    elem.clear()
            print(f"Excel sheet: {selected[0]} | Nonempty rows: {len(lines):,}")
            return "\n".join(lines) + ("\n" if lines else "")

    raise ValueError("Supported dataset extensions: .txt, .csv, .tsv, .xlsx")



def load_training_text(path: Path, sheet=None, columns=None, header=False, qa_format=False):
    if path.suffix.lower() == ".jsonl":
        examples = []
        with path.open(encoding="utf-8") as stream:
            for lineno, line in enumerate(stream, 1):
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    print(f"Skipping malformed JSON line {lineno}", file=sys.stderr)
                    continue
                if event.get("kind") == "teach":
                    q = str(event.get("question", "")).strip()
                    a = str(event.get("answer", "")).strip()
                    if q and a:
                        examples.append(f"প্রশ্ন: {q}\nউত্তর: {a}\n\n")
        if not examples:
            raise ValueError("No approved 'teach' examples in chat memory. Teach an answer in the GUI first.")
        return "".join(examples)
    text = read_dataset(path, sheet=sheet, columns=columns, header=header)
    if qa_format and path.suffix.lower() in {".csv", ".tsv", ".xlsx"}:
        records = []
        for row in text.splitlines():
            parts = row.split("\t", 1)
            if len(parts) == 2 and parts[0].strip() and parts[1].strip():
                records.append(f"প্রশ্ন: {parts[0].strip()}\nউত্তর: {parts[1].strip()}\n\n")
        if not records:
            raise ValueError("--qa-format requires two nonempty columns")
        return "".join(records)
    return text


def split_corpus(text: str, val_fraction: float, seed: int, shuffle_records: bool):
    """Split separate Q/A records to avoid cutting an answer in half."""
    if shuffle_records and "\n\n" in text:
        records = [item.strip() for item in text.split("\n\n") if item.strip()]
        if len(records) > 5:
            rng = np.random.default_rng(seed)
            rng.shuffle(records)
            border = max(1, min(len(records) - 1, int(len(records) * (1 - val_fraction))))
            return ("\n\n".join(records[:border]) + "\n\n",
                    "\n\n".join(records[border:]) + "\n\n")
    split = max(1, min(len(text) - 1, int(len(text) * (1 - val_fraction))))
    return text[:split], text[split:]


def validation_loss(model, stream, positions, batch_size=256):
    if len(positions) == 0:
        return float("nan")
    total = 0.0
    offsets = np.arange(model.context, dtype=np.int64)
    for start in range(0, len(positions), batch_size):
        pos = positions[start:start + batch_size]
        xb = stream[pos[:, None] - model.context + offsets[None, :]]
        logits = model.forward(xb)
        probs = softmax(logits)
        target = stream[pos]
        total += float(-np.log(np.maximum(probs[np.arange(len(pos)), target], 1e-12)).sum())
    return total / len(positions)


def train(args):
    path = Path(args.data)
    if not path.is_file():
        raise SystemExit(f"Dataset not found: {path}")
    text = load_training_text(path, args.sheet, args.columns, args.skip_header, args.qa_format)
    if not text:
        raise SystemExit("Dataset is empty")
    target = Path(args.out)
    if args.resume:
        model, chars, config = TinyGPT.load(args.resume)
        if args.context is not None and args.context > model.context:
            model.extend_context(args.context)
            print(f"Context expanded: {config['context']} -> {model.context}")
            config["context"] = model.context
        elif args.context is not None and args.context < model.context:
            raise SystemExit("Cannot reduce --context with --resume")
        fresh = sorted(set(text) - set(chars))
        if fresh:
            model.extend_vocab(len(fresh))
            chars += fresh
        print(f"Resumed from {args.resume}; optimizer steps={model.opt_step:,}; new chars={len(fresh)}")
    else:
        chars = sorted(set(text))
        if len(chars) < 2:
            raise SystemExit("At least two distinct characters required")
        config = {"context": args.context or 16, "emb": args.emb, "hidden": args.hidden, "seed": args.seed}
        model = TinyGPT(len(chars), **config)
    if not 0 < args.val_fraction < 0.5:
        raise SystemExit("--val-fraction must be between 0 and 0.5")
    train_text, val_text = split_corpus(text, args.val_fraction, args.seed, args.shuffle_records)
    if len(train_text) <= model.context or len(val_text) <= model.context:
        raise SystemExit("Training and validation segments must each be longer than context")
    stoi = {c: i for i, c in enumerate(chars)}
    train_ids = np.fromiter((stoi[c] for c in train_text), dtype=np.int32, count=len(train_text))
    val_ids = np.fromiter((stoi[c] for c in val_text), dtype=np.int32, count=len(val_text))
    positions = np.arange(model.context, len(train_ids), dtype=np.int32)
    val_pos = np.arange(model.context, len(val_ids), dtype=np.int32)
    if args.eval_max > 0 and len(val_pos) > args.eval_max:
        val_pos = val_pos[np.linspace(0, len(val_pos)-1, args.eval_max, dtype=np.int64)]
    rng = np.random.default_rng(args.seed)
    batches_per = (len(positions) + args.batch_size - 1) // args.batch_size
    steps = max(1, batches_per * args.epochs)
    completed = 0
    start_time = last_progress = time.monotonic()
    best = float('inf')
    patience = 0
    offsets = np.arange(model.context, dtype=np.int64)
    best_file = target.with_name(target.stem + "-best.npz")
    print(f"Dataset: {path} | characters={len(text):,}, vocabulary={len(chars)}, params={sum(x.size for x in model.p.values()):,}")
    print(f"Context={model.context} | train={len(positions):,}, val={len(val_pos):,} examples | {batches_per:,} batches/epoch")
    print(f"Latest checkpoint: {target} (atomic save); Ctrl+C saves current weights")
    try:
        for epoch in range(1, args.epochs + 1):
            order = rng.permutation(positions)
            batch_sum = 0.0
            seen = 0
            for i in range(0, len(order), args.batch_size):
                pos = order[i:i + args.batch_size]
                xb = train_ids[pos[:, None] - model.context + offsets[None, :]]
                yb = train_ids[pos]
                lr = args.lr * max(0.1, 1.0 - (epoch - 1) / args.epochs)
                loss, grads = model.loss_and_grads(xb, yb)
                model.update(grads, lr, grad_clip=args.grad_clip)
                batch_sum += loss
                seen += 1
                completed += 1
                now = time.monotonic()
                if now - last_progress >= args.progress_interval:
                    pct = completed / steps * 100
                    rate = completed / max(1e-6, now - start_time)
                    eta = (steps - completed) / max(rate, 1e-9) / 60
                    msg = f"Epoch {epoch}/{args.epochs} | Total {pct:5.1f}% | Batch {seen:,}/{batches_per:,} | loss={batch_sum/seen:.4f} | ETA {eta:.1f}m"
                    print("\r" + msg.ljust(110), end="" if sys.stdout.isatty() else "\n", flush=True)
                    last_progress = now
            if sys.stdout.isatty():
                print()
            avg = batch_sum/max(1,seen)
            val_loss = validation_loss(model,val_ids,val_pos)
            print(f"Epoch {epoch}/{args.epochs}: train={avg:.4f} val={val_loss:.4f} elapsed={time.monotonic()-start_time:.1f}s", flush=True)
            if val_loss < best:
                best = val_loss
                patience = 0
                if args.save_best:
                    model.save(best_file, chars, config)
                    print(f"  Best model: {best_file}")
            else:
                patience += 1
            if epoch % args.save_every == 0:
                model.save(target, chars, config)
                print(f"  Checkpoint saved: {target}", flush=True)
            if args.patience and patience >= args.patience:
                print(f"Early stopping (validation did not improve for {args.patience} epochs)")
                break
    except KeyboardInterrupt:
        print("\nInterrupted. Saving latest state...")
    finally:
        model.save(target, chars, config)
        print(f"Model saved: {target}")
    print("Sample:")
    print(model.generate(stoi, chars, seed_text=args.prompt,
                         length=args.gen_length, temperature=args.temperature,
                         top_k=args.top_k, seed=args.seed))


def generate(args):
    model, chars, _ = TinyGPT.load(args.model)
    stoi = {ch: i for i,ch in enumerate(chars)}
    prompt = args.prompt
    sample = model.generate(stoi,chars,prompt,args.length,args.temperature,args.top_k,args.seed)
    if args.reply_only:
        sample = sample[len(prompt):]
        sample = sample.split("\n")[0].strip()
    print(sample)


def main():
    ap = argparse.ArgumentParser(description="NeO-RON v5 NumPy language model (v4 compatible)")
    sub = ap.add_subparsers(dest="command", required=True)
    t = sub.add_parser("train")
    t.add_argument("--data", default="input.txt")
    t.add_argument("--out", default="NeO-RON-V-0.5.npz")
    t.add_argument("--resume", default=None)
    t.add_argument("--sheet", default=None)
    t.add_argument("--columns", type=lambda s:[int(x) for x in s.split(',')],default=None)
    t.add_argument("--skip-header",action="store_true")
    t.add_argument("--qa-format",action="store_true", help="Turn two XLSX/CSV columns into Q/A prompts")
    t.add_argument("--shuffle-records",action="store_true",help="Shuffle Q/A blocks before train/val split")
    t.add_argument("--epochs",type=int,default=10)
    t.add_argument("--batch-size",type=int,default=64)
    t.add_argument("--context",type=int,default=None,help="Fresh context (default16) or expand resume context")
    t.add_argument("--emb",type=int,default=32)
    t.add_argument("--hidden",type=int,default=64)
    t.add_argument("--lr",type=float,default=0.003)
    t.add_argument("--grad-clip",type=float,default=1.0)
    t.add_argument("--seed",type=int,default=42)
    t.add_argument("--val-fraction",type=float,default=0.1)
    t.add_argument("--eval-max",type=int,default=20000)
    t.add_argument("--save-every",type=int,default=1)
    t.add_argument("--save-best",action="store_true")
    t.add_argument("--patience",type=int,default=0)
    t.add_argument("--progress-interval",type=float,default=2.0)
    t.add_argument("--prompt",default="প্রশ্ন: তোমার নাম কী?\nউত্তর:")
    t.add_argument("--gen-length",type=int,default=100)
    t.add_argument("--temperature",type=float,default=0.65)
    t.add_argument("--top-k",type=int,default=10)
    t.set_defaults(func=train)
    g = sub.add_parser("generate")
    g.add_argument("--model",default="NeO-RON-V-0.5.npz")
    g.add_argument("--prompt",default="প্রশ্ন: তুমি কেমন আছো?\nউত্তর:")
    g.add_argument("--length",type=int,default=120)
    g.add_argument("--temperature",type=float,default=0.65)
    g.add_argument("--top-k",type=int,default=10)
    g.add_argument("--seed",type=int,default=123)
    g.add_argument("--reply-only",action="store_true")
    g.set_defaults(func=generate)
    args = ap.parse_args()
    if hasattr(args,'batch_size') and args.batch_size < 1: ap.error("batch-size must be >=1")
    if hasattr(args,'epochs') and args.epochs < 1: ap.error("epochs must be >=1")
    if hasattr(args,'context') and args.context is not None and args.context < 1: ap.error("context must be >=1")
    if hasattr(args,'columns') and args.columns is not None and any(x < 1 for x in args.columns): ap.error("columns must be positive")
    if hasattr(args,'save_every') and args.save_every < 1: ap.error("save-every must be >=1")
    if hasattr(args,'progress_interval') and args.progress_interval <= 0: ap.error("progress-interval must be >0")
    if hasattr(args,'temperature') and args.temperature <= 0: ap.error("temperature must be >0")
    args.func(args)

if __name__ == "__main__":
    main()
